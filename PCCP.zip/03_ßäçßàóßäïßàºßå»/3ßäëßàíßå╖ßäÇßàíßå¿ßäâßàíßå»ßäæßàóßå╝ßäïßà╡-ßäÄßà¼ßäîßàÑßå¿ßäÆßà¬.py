# 삼각 달팽이

def solution(n):
    res = [[0] * i for i in range(1, n+1)]
    y, x = -1, 0
    num = 1

    for i in range(n):
        for _ in range(1, n):
            angle = i % 3
            if angle == 0:
                y += 1
            elif angle == 1:
                x += 1
            elif angle == 2:
                x -= 1
                y -= 1
            res[y][x] = num
            num += 1

    return [i for j in res for j in i]